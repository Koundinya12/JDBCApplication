package sat.model;
public class Person {
	private String Name;
	private Address address;
	private int sat_score;
	private String pass_fail;
	public Person(String name, Address address,  int sat_score, String pass_fail) {
		super();
		Name = name;
		this.address = address;
		
		this.sat_score = sat_score;
		this.pass_fail = pass_fail;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public int getSat_score() {
		return sat_score;
	}
	public void setSat_score(int sat_score) {
		this.sat_score = sat_score;
	}
	public Person() {
		super();
	}
	public String getPass_fail() {
		return pass_fail;
	}
	public void setPass_fail(String pass_fail) {
		this.pass_fail = pass_fail;
	}
	@Override
	public String toString() {
		return "Person [Name=" + Name + ", address=" + address +  ", sat_score=" + sat_score
				+ ", pass_fail=" + pass_fail + "]";
	}
	
	
}
