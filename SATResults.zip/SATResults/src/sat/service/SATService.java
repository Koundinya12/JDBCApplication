package sat.service;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import sat.dao.SATDao;
import sat.model.Person;

public class SATService {

	private SATDao dao;
	Scanner sc = new Scanner(System.in);

	public void createTableService() {
		dao.createTable();
	}

	public SATService(SATDao dao) {
		this.dao = dao;

	}

	public int addItem(Person p) {
		// TODO Auto-generated method stub
		// Here we are considering real time SAT score, the max score in SAT is 1600
		int frac = (int) (p.getSat_score() * 100);
		int percent = (frac / 1600);
		if (percent > 30) {

			p.setPass_fail("Pass");
		} else {
			p.setPass_fail("Fail");
		}
		int flag=dao.addItemDao(p);
		return flag;
	}

	public List<Person> getAll() {
		// TODO Auto-generated method stub
		return dao.getAllData();
	}

	public int getRank(String name) {
		// TODO Auto-generated method stub
		List<Person> plist = dao.getAllData();
		Collections.sort(plist, Comparator.comparingInt(Person::getSat_score).reversed());

		int rank = 0;
		for (Person p : plist) {
			rank++;
			if (p.getName().equals(name)) {
				return rank;
			}
		}
		return -1;

	}

	public int updateScore(String name, int score) {
		// TODO Auto-generated method stub
		int frac = (int) (score * 100);
		int percent = (frac / 1600);
		String temp=null;
		if (percent > 30) {

			temp="Pass";
		} else {
			temp="Fail";
		}
		return dao.updateScoreByName(name, score,temp);
	}
	
	public int deleteRecord(String name)
	{
		return dao.deleteRecordByName(name);
	}

}
