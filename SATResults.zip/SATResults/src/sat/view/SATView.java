package sat.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import sat.model.Address;
import sat.model.Person;

import sat.service.SATService;

public class SATView {

	private SATService service;
	Scanner sc = new Scanner(System.in);

	public SATView(SATService service) {
		this.service = service;
		createTable();
	}

	public void createTable() {
		service.createTableService();
		menu();
	}

	public void menu() {
		while (true) {
			System.out.println("1.Insert data");
			System.out.println("2.View all data");
			System.out.println("3.Get Rank");
			System.out.println("4.Update score");
			System.out.println("5.Delete one record");
			System.out.println("6.Exit");
			int choice = sc.nextInt();
			sc.nextLine();
			if (choice == 1) {
				System.out.println("Enter the name of the candidate");
				String name = sc.nextLine();
				System.out.println("Enter the city of the candidate");
				String city = sc.nextLine();
				System.out.println("Enter the country of the candidate");
				String country = sc.nextLine();
				System.out.println("Enter the pincode of the candidate");
				String pincode = sc.nextLine();
				System.out.println("Enter the SAT score of the candidate");
				int score = sc.nextInt();
				sc.nextLine();
				Person p = new Person(name, new Address(city, country, pincode), score, "");
				int flag = service.addItem(p);
				if (flag == 1)
					System.out.println("Candidate data inserted successfully");
				else
					System.out.println("Sorry, candidate " + p.getName() + " already exist");

			} else if (choice == 2) {
				List<Person> li = service.getAll();
				if (li.isEmpty()) {
					System.out.println("No candidates present");
					return;
				}
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				System.out.println(gson.toJson(li));

			} else if (choice == 3) {
				System.out.println("Enter the name to get the rank");
				String name = sc.nextLine();
				int rank = service.getRank(name);
				if (rank != -1)
					System.out.println("The rank of " + name + " is: " + rank);
				else
					System.out.println("There is no person with the name " + name);
			} else if (choice == 4) {
				System.out.println("Enter name to update the SAT score");
				String name = sc.nextLine();
				System.out.println("Enter new score to be updated");
				int score = sc.nextInt();
				sc.nextLine();
				int flag = service.updateScore(name, score);
				if (flag == 1)
					System.out.println("SAT score of " + name + " updated successfully");
				else
					System.out.println("No person found with the name " + name);
			} else if (choice == 5) {
				System.out.println("Enter name to delete the record");
				String name = sc.nextLine();
				int flag = service.deleteRecord(name);
				if (flag == 1)
					System.out.println("The record with the " + name + " is deleted successfully");
				else
					System.out.println("No person found with the name " + name);
			} else {
				break;
			}
		}
	}

}
