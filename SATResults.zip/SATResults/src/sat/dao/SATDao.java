package sat.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import sat.model.Address;
import sat.model.Person;

public class SATDao {

	private Connection connection;

	public SATDao(Connection connection) {
		this.connection = connection;
	}

	public void createTable() {
		String sql = "CREATE TABLE IF NOT EXISTS SAT_CANDIDATES" + "(" + " Name varchar(100) NOT NULL,"
				+ " address_city varchar(100) NOT NULL," + " address_country varchar(100),"
				+ " address_pincode varchar(10)," + "  sat_score int," + "  PRIMARY KEY (Name),"
				+ "  pass_fail varchar(10)" + ")";
		try {
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return;
	}

	public int addItemDao(Person p) {
		// TODO Auto-generated method stub
		String sql = "insert into SAT_CANDIDATES value(?,?,?,?,?,?)";
		try {
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setString(1, p.getName());
			ps.setString(2, p.getAddress().getCity());
			ps.setString(3, p.getAddress().getCountry());
			ps.setString(4, p.getAddress().getPincode());
			ps.setInt(5, p.getSat_score());
			ps.setString(6, p.getPass_fail());
			ps.executeUpdate();
			return 1;
		} catch (SQLException e) {
			if (e instanceof java.sql.SQLIntegrityConstraintViolationException)
			{
				
				return 0;
			}
				
			else
				e.printStackTrace();
		}
		return 0;
	}

	private static final String SELECT_ALL_RESULTS = "SELECT * FROM SAT_CANDIDATES";

	public List<Person> getAllData() {
		List<Person> plist = new ArrayList<>();

		try {
			PreparedStatement stmt = connection.prepareStatement(SELECT_ALL_RESULTS);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Person p = new Person();
				p.setName(rs.getString("Name"));
				Address address = new Address();
				address.setCity(rs.getString("address_city"));
				address.setCountry(rs.getString("address_country"));
				address.setPincode(rs.getString("address_pincode"));
				p.setAddress(address);
				p.setSat_score(rs.getInt("sat_score"));
				p.setPass_fail((rs.getString("pass_fail")));

				plist.add(p);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return plist;
	}

	private static final String UPDATE_SCORE_BY_NAME = "UPDATE SAT_CANDIDATES SET sat_score = ?, pass_fail=? WHERE Name = ?";

	public int updateScoreByName(String name, int newScore, String state) {
		try {
			PreparedStatement stmt = connection.prepareStatement(UPDATE_SCORE_BY_NAME);

			// Set the values for the prepared statement
			stmt.setInt(1, newScore);
			stmt.setString(2, state);
			stmt.setString(3, name);

			// Execute the update statement
			int rowsUpdated = stmt.executeUpdate();

			if (rowsUpdated > 0) {
				return 1;
			} else {

				return 0;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return 0;
	}

	private static final String DELETE_RECORD_BY_NAME = "DELETE FROM SAT_CANDIDATES WHERE name = ?";

	public int deleteRecordByName(String name) {
		try {
				PreparedStatement stmt = connection.prepareStatement(DELETE_RECORD_BY_NAME);

			// Set the value for the prepared statement
			stmt.setString(1, name);

			// Execute the delete statement
			int rowsDeleted = stmt.executeUpdate();

			if (rowsDeleted > 0) {
				return 1;
			} else {
				return 0;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
}
