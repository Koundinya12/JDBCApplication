package sat.connection;


import com.mysql.cj.jdbc.Driver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class MyDataSource {
	
	public static Connection getConnection() {
		return connection;
	}
	static Connection connection;
	private static final Properties properties = loadProperties();
    
	private static Properties loadProperties() {
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream("application.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return properties;
    }
	static{
		
			
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e1) {
				
				e1.printStackTrace();
			}
			//Get the database username and password from properties file
			Properties p=loadProperties();
			String U_name=p.getProperty("db.username");
			String pwd=p.getProperty("db.password");
			//System.out.println(x+" "+y);
			String url="jdbc:mysql://localhost:3306/";
			String username=U_name;
			String database="item";
			String password=pwd;
			
			try {
				connection=DriverManager.getConnection(url+database, username, password);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
	
	}
}
