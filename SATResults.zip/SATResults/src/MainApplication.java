

import java.sql.Connection;

import sat.connection.MyDataSource;
import sat.dao.SATDao;
import sat.service.SATService;
import sat.view.SATView;

public class MainApplication {

	public static void main(String[] args) {
		Connection connection=MyDataSource.getConnection();
		SATDao dao=new SATDao(connection);
		SATService service=new SATService(dao);
		new SATView(service);

	}

}
